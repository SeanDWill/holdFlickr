package com.example.flickrviewer;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
//Name: Sean Williams       Course: CSC 317     Instructor: Prof. Dicken
/**
 * This class will be used to access the flickr.com public api for processing new image requests
 * as well as gaining access to the url of the original post if requested
 */
public class MainActivity extends AppCompatActivity {
    /**
     * This group of variable are used together to access the flickr api
     */
    private static String getImg = "https://www.flickr.com/services/rest/?method=" +
            "flickr.photos.getRecent&api_key=c68268937007bf1cc8ac4be2d67276b0&extras=" +
            "url_c%2C+tags%2C+last_update%2C+owner_name%2C+date_upload%2C+date_taken%2C+" +
            "original_format&per_page=2&page=";
    private static int pageNum = 0;
    private static String getImgEnd = "&format=json&nojsoncallback=1";


    private Button buttonImageTop;// Reference to the top button for setting image
    private Button buttonImageBot;// Reference to the bottom button for setting image

    private static AppCompatActivity thisApp;// Refernce to this activity (this app)

    /**
     * This group of strings are used and all reset occasionally based on the current users image
     * and where to access that specific URL for the top image (button)
     */
    private String topViewURL = "https://flickr.com/photos/";
    private static String topOwner = "";
    private static String topPostID = "";


    private static Bitmap topNewImag;// Reference to the top image to set on the UI Button
    private static Bitmap botNewImag;// Reference to the bottom image to set on the UI Button

    /**
     * This group of strings are used and all reset occasionally based on the current users image
     * and where to access that specific URL for the bottom image (button)
     */
    private String botViewURL = "https://flickr.com/photos/";
    private static String botOwner = "";
    private static String botPostID = "";

    private Intent workerObj;// The current intent sent to start fetching images in the background

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonImageTop = findViewById(R.id.topView);
        buttonImageBot = findViewById(R.id.botView);
        thisApp = this;
    }

    /**
     * This method will be called when the app is sent into the background and will start processing
     * requests in order to gain new photos for the button on the UI
     */
    public void onPause() {
        try{
            BackgroundService.isPaused = true;
            super.onPause();
            Handler handler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    DownloadTask thisDl = (DownloadTask) msg.obj;
                    if (BackgroundService.isPaused) {
                        thisDl.execute();
                    }
                }
            };
            workerObj = new Intent(this, BackgroundService.class);
            workerObj.putExtra("MESSENGER", new Messenger(handler));
            startService(workerObj);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }


    /**
     * this method will be called when the app is called into the foreground and will stop the
     * intent service and in that will disable the ability from running the execute provided one
     * was threaded
     */
    protected void onResume() {
        super.onResume();
        if (workerObj != null){
                stopService(workerObj);
        }
    }

    /**
     * This method will be used in order to open the actual url from flickr.com of the post of
     * the photo inside of the button (if the image is the default logo it will open flickr explore)
     * @param v v will be the button of the image that was clicked (either the top or bottom image)
     */
    public void openWebView(View v){
        String holdURL = topViewURL+"/";
        if (v == buttonImageTop){
            holdURL = topViewURL+topOwner+topPostID;
        }
        if (v == buttonImageBot){
            holdURL = botViewURL+botOwner+botPostID;
        }
        Intent openURL = new Intent(getApplicationContext(), runURLActivity.class);
        openURL.putExtra("URL", holdURL);
        startActivity(openURL);
    }


    /**
     * This method will be used to set new images on the screen by sending a process request with
     * the incrementation of  the page number attached to the api request used in the DownladTask
     * AsyncTask class
     * @param v v will be the next button being pressed
     */
    public void newImageViews(View v){
        pageNum += 1;
        new DownloadTask().execute();
    }

    /**
     * This method will be used to try to go back to the previous set of images that were on the
     * screen by decrementing down but trying to avoid negative numbers
     * @param v v will be the back button being pressed
     */
    public void oldImageViews(View v){
        if (pageNum >1) {
            pageNum -= 1;
        }
        new DownloadTask().execute();
    }

    /**
     * This method will be used when the refresh button was pressed and will reset the views to what
     * the api request recieves from page 1
     * @param v v will be the refresh button which "resetting" the views to the originals (they may change)
     */
    public void beginImageViews(View v){
        pageNum = 1;
        new DownloadTask().execute();
    }

    /**
     *
     * This class will be called whenever there has been a request sent (button was pressed or app
     * was no longer in foreground and will process requests periodically) and it will attempt to
     * access the api from flickr in order to gain access to a json structure of data for two
     * public photos with tags, times, posting, owner, etc. which will be used to populate
     * the UI with images and information about them
     */
    public static class DownloadTask extends AsyncTask<Object, Void, JSONObject> {
        @Override
        protected JSONObject doInBackground(Object[] objects) {
            try {
                String json = "" ;
                String line;
                URL url = new URL(getImg +Integer.toString(pageNum)+getImgEnd);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while ((line = in.readLine()) != null) {
                    System.out.println("JSON LINE " + line);
                    json += line;
                }
                JSONObject jsonObject = new JSONObject(json);
                in.close();
                JSONObject flickrPhotos = jsonObject.getJSONObject("photos");
                JSONArray photoArray =  flickrPhotos.getJSONArray("photo");
                for (int i = 0; i< photoArray.length();i++) {
                    String bitmapStr = photoArray.getJSONObject(i).getString("url_c");
                    Bitmap bitmapAtI = getBitmapFromURL(bitmapStr);
                    if (i==0){
                        topNewImag = bitmapAtI;
                    }
                    else{
                        botNewImag = bitmapAtI;
                    }
                }
                return jsonObject;
            } catch (Exception e) { e.printStackTrace(); }
            return null;
        }

        /**
         * This method will be used to mine data from the url that was sent to flickr to recieve
         * access to public photos in order to process requests
         * @param flickrJSON JSONObject from the api request sent
         */
        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(JSONObject flickrJSON) {
            try {
                JSONObject flickrPhotos = flickrJSON.getJSONObject("photos");
                JSONArray photoArray =  flickrPhotos.getJSONArray("photo");
                for (int i = 0; i< photoArray.length(); i++){
                    String tagsStr = photoArray.getJSONObject(i).getString("tags");
                    String timeTakenStr = photoArray.getJSONObject(i).getString("dateupload");
                    String imageTypeStr = photoArray.getJSONObject(i).getString("originalformat");
                    String ownerStr = photoArray.getJSONObject(i).getString("owner");
                    String ownerId = photoArray.getJSONObject(i).getString("id");
                    long timeStamp = Long.parseLong(timeTakenStr);
                    java.util.Date date = new java.util.Date((long)timeStamp*1000);
                    SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String formattedDate = sdf.format(date);
                    String[] dateTime = formattedDate.split(" ", 2);
                    codeConsolidation(ownerStr, ownerId, dateTime, imageTypeStr, tagsStr, i);
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * This method will be used to set most of the user interface from the api request that was
     * sent to flickr by setting a picture that was gained from a request to a button which can
     * open a webpage of the original post from that photo, in addition this will also set the
     * date, time, image source, tags, for both views (provided the request is properly fulfilled!)
     *
     * @param ownerStr String value for the owner name of the content (needed for opening webpage)
     * @param ownerId String value of the owners ID (needed for opening webpage)
     * @param dateTime String[] of the time split in ["YYYY-MM-DD", "HH:MM:SS"] format
     * @param imageTypeStr String of the image file type i.e. "jpg"
     * @param tagsStr String of the tags from the users post
     * @param i int value used to determine top view or bottom view
     */
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private static void codeConsolidation(String ownerStr, String ownerId, String[] dateTime,
                                          String imageTypeStr, String tagsStr, int i){
        if (i == 0){
            topOwner = ownerStr+"/";
            topPostID = ownerId;
            BitmapDrawable newImage = new BitmapDrawable(
                    MainActivity.thisApp.getResources(), topNewImag);
            TextView dateTop = MainActivity.thisApp.findViewById(R.id.dateTakenTop);
            TextView timeTop = MainActivity.thisApp.findViewById(R.id.timeTakenTop);
            TextView srcTop = MainActivity.thisApp.findViewById(R.id.imgTop);
            TextView tagTop = MainActivity.thisApp.findViewById(R.id.tagTop);
            Button imageTop = MainActivity.thisApp.findViewById(R.id.topView);
            imageTop.setBackground(newImage);
            dateTop.setText(dateTime[0]);
            timeTop.setText(dateTime[1]);
            srcTop.setText(imageTypeStr);
            tagTop.setText(tagsStr);
        }
        else{
            botOwner = ownerStr+"/";
            botPostID = ownerId;
            BitmapDrawable newImage = new BitmapDrawable(
                    MainActivity.thisApp.getResources(), botNewImag);
            TextView dateBot = MainActivity.thisApp.findViewById(R.id.dateTakenBot);
            TextView timeBot = MainActivity.thisApp.findViewById(R.id.timeTakenBot);
            TextView srcBot = MainActivity.thisApp.findViewById(R.id.imgBot);
            TextView tagBot = MainActivity.thisApp.findViewById(R.id.tagBot);
            Button imageBot = MainActivity.thisApp.findViewById(R.id.botView);
            imageBot.setBackground(newImage);
            dateBot.setText(dateTime[0]);
            timeBot.setText(dateTime[1]);
            srcBot.setText(imageTypeStr);
            tagBot.setText(tagsStr);
        }
    }

    /**
     * This method will be used to grab a picture from flickr using their api services
     * @param src this will be the URL source to which we will be grabbing a pic from flickr.com
     * @return this return value will be the Bitmap for the public access image
     */
    public static Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}


