package com.example.flickrviewer;

import android.app.IntentService;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;

import androidx.annotation.Nullable;

import org.json.JSONObject;

public class BackgroundService extends IntentService {
    public static boolean isPaused; // Boolean used to set the intent  (background process)

    /**
     * This method will be used to process request to periodically (12 secs) send a request for
     * the flickr api via the DownloadTask class
     * @param intent this intent will be used to send the request access the flickr url via api
     */
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            return;
        }
        Messenger messenger = (Messenger) bundle.get("MESSENGER");
        while (isPaused) {
            MainActivity.DownloadTask hold = new MainActivity.DownloadTask();
            Message msg = Message.obtain();
            msg.obj = hold;
            try {
                Thread.sleep(12000);
                messenger.send(msg);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        }

    /**
     * Instantiate handler
     */
    @Override
    public void onCreate() {
        handler = new Handler();
        super.onCreate();
    }


    /**
     * remove handlers messages and pause this request
     */
    @Override
    public void onDestroy(){
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        this.isPaused = false;
    }

    static Handler handler;

    public BackgroundService() {
        super("BackgroundService");
    }


}