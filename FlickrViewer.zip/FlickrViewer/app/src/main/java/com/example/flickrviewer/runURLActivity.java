package com.example.flickrviewer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

public class runURLActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run_url);
        Intent sentIntent = getIntent();
        String urlToOpen = sentIntent.getStringExtra("URL");
        WebView myWebView = findViewById(R.id.webView);
        myWebView.loadUrl(urlToOpen);
    }
}
