package com.example.flickrviewer;

import androidx.appcompat.app.AppCompatActivity;

public class DownloadRunnable implements Runnable {

    long numberToCheck = 0;
    AppCompatActivity invokerActivity = null;
    boolean isPrime = false;

    public DownloadRunnable(AppCompatActivity activity) {

        invokerActivity = activity;
    }

    @Override
    public void run() {
        invokerActivity.runOnUiThread(new Runnable() {
            public void run() {
                MainActivity.DownloadTask dt = new MainActivity.DownloadTask();
                dt.execute();
            }
    });
    }
}